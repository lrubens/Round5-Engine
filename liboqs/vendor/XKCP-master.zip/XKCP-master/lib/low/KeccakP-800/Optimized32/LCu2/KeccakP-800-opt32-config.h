/*
This file defines some parameters of the implementation in the parent directory.
*/

#define KeccakP800_implementation_config "lane complementing, 2 rounds unrolled"
#define KeccakP800_unrolling 2
#define KeccakP800_useLaneComplementing
