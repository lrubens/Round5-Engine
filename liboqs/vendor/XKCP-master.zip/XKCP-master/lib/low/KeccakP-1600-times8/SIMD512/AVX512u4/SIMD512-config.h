/*
This file defines some parameters of the implementation in the parent directory.
*/

#define KeccakP1600times8_implementation_config "AVX512, 4 rounds unrolled"
#define KeccakP1600times8_unrolling 4
#define KeccakP1600times8_useAVX512
