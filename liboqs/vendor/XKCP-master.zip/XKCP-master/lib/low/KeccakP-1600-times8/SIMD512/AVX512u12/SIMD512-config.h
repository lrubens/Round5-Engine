/*
This file defines some parameters of the implementation in the parent directory.
*/

#define KeccakP1600times8_implementation_config "AVX512, 12 rounds unrolled"
#define KeccakP1600times8_unrolling 12
#define KeccakP1600times8_useAVX512
