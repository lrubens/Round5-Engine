/*
This file defines some parameters of the implementation in the parent directory.
*/

#define KeccakP1600times2_implementation_config "AVX512, all rounds unrolled"
#define KeccakP1600times2_fullUnrolling
#define KeccakP1600times2_useAVX512
