/*
This file defines some parameters of the implementation in the parent directory.
*/

#define KeccakP1600times2_implementation_config "XOP, all rounds unrolled"
#define KeccakP1600times2_fullUnrolling
#define KeccakP1600times2_useSSE
#define KeccakP1600times2_useSSE2
#define KeccakP1600times2_useXOP
