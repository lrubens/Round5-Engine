/*
This file defines some parameters of the implementation in the parent directory.
*/

#define KeccakP1600times2_implementation_config "SSE2, 2 rounds unrolled"
#define KeccakP1600times2_unrolling 2
#define KeccakP1600times2_useSSE
#define KeccakP1600times2_useSSE2
