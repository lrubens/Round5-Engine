/* Placeholder for KeccakP-1600-times*-SnP.h. Not trying to do parallelism in the SUPERCOP packages (yet). */
