#define CRYPTO_BYTES        32
