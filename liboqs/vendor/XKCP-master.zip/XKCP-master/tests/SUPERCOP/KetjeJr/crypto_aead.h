/* Placeholder for crypto_aead.h */
