
int crypto_hash(
	unsigned char *out,
	const unsigned char *in,
	unsigned long long inlen
	);